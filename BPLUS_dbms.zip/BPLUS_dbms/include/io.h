#ifndef IO_H
#define IO_H

#include "structures.h"
void Print_Medicine_Info(const MedicineNode *node);
void Print_Supplier_Info(const SupplierNode *node);
void Print_Batch_Info(const BatchNode *node, int margin);


void Print_BatchTable_Header();
void Print_BatchTable_Row(const BatchNode *node);
void Print_BatchTable_Footer();

#endif // !IO_H
