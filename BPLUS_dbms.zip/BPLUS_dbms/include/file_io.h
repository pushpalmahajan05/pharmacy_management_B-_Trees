#ifndef FILE_IO
#define FILE_IO

int Get_Medicines_From_File(void **MedRoot, const char *file_path);
int Get_Suppliers_From_File(void **SuppRoot, const char *file_path);
int Get_Batches_From_File(void **MedRoot, void **SupRoot, void **ExpRoot, void **TurnOverRoot, void **UniqueMedRoot, const char *file_path);

#endif // !FILE_IO
