#ifndef STRUCTURES_H
#define STRUCTURES_H

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef float real;
#define REAL_MAX UINT_MAX
typedef uint32_t REALTONATURAL;

typedef struct {
    char MedId[8];
    char MedName[48];
    uint64_t TotalQuantity;
    uint64_t TotalSales;
    real price_per_unit;
    uint64_t ReorderLevel;
} MedicineData;

typedef struct {
    char BatchId[8];
    uint64_t BatchQuantity;
    uint64_t ExpiryDate;
    real PurchasePrice;
} BatchData;

typedef struct {
    char SupplierId[8];
    char SupplierName[48];
    uint64_t Quantity;
    uint64_t Contact;
    real Turnover;
} SupplierData;

typedef struct {
    SupplierData data;
    void *MedRoot;
    uint64_t MedCount;
} SupplierNode;

typedef struct {
    MedicineData medicine;
    void *BatchRoot;
    SupplierNode *AssociateSupps;
} MedicineNode;

typedef struct {
    BatchData batch;
    SupplierNode *AssociateSupp;
    MedicineNode *AssociateMed;
} BatchNode;

typedef struct {
    MedicineNode *medicine;
    void *BatchRoot;
} MedRef;

#endif // !STRUCTURES_H
