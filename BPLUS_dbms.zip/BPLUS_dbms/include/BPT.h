#ifndef BPT_H
#define BPT_H

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#define MINIMUM_DEGREE_OF_B_TREE 3
#define KEYS_LOWER_BOUND_INTERNAL_NODE (MINIMUM_DEGREE_OF_B_TREE - 1)
#define KEYS_UPPER_BOUND_INTERNAL_NODE (2 * MINIMUM_DEGREE_OF_B_TREE - 1)
#define CHILDREN_LOWER_BOUND_INTERNAL_NODE (MINIMUM_DEGREE_OF_B_TREE)
#define CHILDREN_UPPER_BOUND_INTERNAL_NODE (2 * MINIMUM_DEGREE_OF_B_TREE)

#define MINIMUM_DEGREE_OF_LEAF_NODE 4
#define KEYS_LOWER_BOUND_LEAF_NODE MINIMUM_DEGREE_OF_LEAF_NODE
#define KEYS_UPPER_BOUND_LEAF_NODE (2 * MINIMUM_DEGREE_OF_LEAF_NODE)

typedef enum {LEAF, INTERNAL} NODE_KIND;

typedef struct LeafNode {
    NODE_KIND kind;
    int numData;
    uint64_t keys[KEYS_UPPER_BOUND_LEAF_NODE];
    void *data[KEYS_UPPER_BOUND_LEAF_NODE];
    struct LeafNode *prev;
    struct LeafNode *next;
} LeafNode;

typedef struct InternalNode {
    NODE_KIND kind;
    int numKeys;
    uint64_t keys[KEYS_UPPER_BOUND_INTERNAL_NODE];
    void *firstChild;
    void *children[CHILDREN_UPPER_BOUND_INTERNAL_NODE - 1];
} InternalNode;

void *CreateNode(NODE_KIND kind);
int search(uint64_t *arr, int size, uint64_t target);
void *Search(void *root, uint64_t key);
void **SearchAddress(void *root, uint64_t key);
void Insert(void **root, uint64_t key, void *value);
void Delete(void **root, uint64_t key);
void BPT_travel(void *node);
void *GetLL(void *root);

#endif // !BPT_H
