#include "./../../include/include.h"

#include <stdio.h>
#include <stdint.h>

void Print_BatchTable_Header() {
    printf("┌──────────┬────────┬────────────┬────────────┬──────────────────────┐\n");
    printf("│ \033[1m%-8s\033[0m │ \033[1m%-6s\033[0m │ \033[1m%-10s\033[0m │ \033[1m%-10s\033[0m │ \033[1m%-20s\033[0m │\n",
           "Batch ID", "Qty", "Exp Date", "Price", "Supplier");
    printf("├──────────┼────────┼────────────┼────────────┼──────────────────────┤\n");
}

void Print_BatchTable_Row(const BatchNode *node) {
    if (!node) return;

    const BatchData *batch = &(node->batch);
    const SupplierNode *supp = node->AssociateSupp;

    const char *supp_name = (supp && supp->data.SupplierName[0]) 
                            ? supp->data.SupplierName : "N/A";

    // Parse date from yyyymmdd -> dd/mm/yyyy
    uint64_t raw_date = batch->ExpiryDate;
    int year  = raw_date / 10000;
    int month = (raw_date / 100) % 100;
    int day   = raw_date % 100;

    // Format the row
    printf("│ \033[38;2;255;255;0m%-8s\033[0m │ %-6llu │ \033[38;2;255;255;0m%02d/%02d/%04d\033[0m │ %10.2f │ %-20s │\n",
           batch->BatchId,
           (unsigned long long)batch->BatchQuantity,
           day, month, year,
           (double)batch->PurchasePrice,
           supp_name);
}

void Print_BatchTable_Footer() {
    printf("└──────────┴────────┴────────────┴────────────┴──────────────────────┘\n");
}

void Print_Batch_Info(const BatchNode *node, int margin)
{
    if (!node) return;

    const BatchData *batch = &(node->batch);
    const SupplierNode *supp = node->AssociateSupp;
    // const MedicineNode *med = node->AssociateMed;

    for (int i = 0; i < margin; ++i) putchar(' ');

    printf(" \033[38;2;255;255;0mBatchID: %s\033[0m | Qty: %llu | \033[38;2;255;255;0mExp: %llu\033[0m | Price: %.2f",
           batch->BatchId,
           (unsigned long long)batch->BatchQuantity,
           (unsigned long long)batch->ExpiryDate,
           (double)batch->PurchasePrice);

    if (supp && supp->data.SupplierName[0]) {
        printf(" | Supplier: %s", supp->data.SupplierName);
    }
    // if (med && med->medicine.MedName[0]) {
    //     printf(" | Medicine: %s", med->medicine.MedName);
    // }

    putchar('\n');
}
