#include "../../include/include.h"
#include <stdio.h>

void Print_Medicine_Info(const MedicineNode *node) {
    if (!node) {
        fprintf(stderr, "\033[1;31m[ERROR]\033[0m Null MedicineNode passed.\n");
        return;
    }

    printf("\n\033[1;34m%-60s\033[0m\n", "====================[ Medicine Information ]====================");
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;215;0m%s\033[0m\n", "Medicine ID", node->medicine.MedId);
    printf(" \033[1m%-20s:\033[0m \033[38;2;0;255;255m%s\033[0m\n", "Medicine Name", node->medicine.MedName);
    printf(" \033[1m%-20s:\033[0m \033[38;2;144;238;144m%lu units\033[0m\n", "Total Quantity", node->medicine.TotalQuantity);
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;105;180m%lu sales\033[0m\n", "Total Sales", node->medicine.TotalSales);
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;165;0m₹ %.2f\033[0m\n", "Price/Unit", node->medicine.price_per_unit);
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;69;0m%lu units\033[0m\n", "Reorder Level", node->medicine.ReorderLevel);
    printf("\033[1;34m%-60s\033[0m\n", "===============================================================");
}
