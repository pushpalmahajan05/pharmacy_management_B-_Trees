#include "../../include/include.h"

void Print_Supplier_Info(const SupplierNode *node) {
    if (!node) {
        fprintf(stderr, "\033[1m\033[38;2;255;0;0mERROR:\033[0m Supplier node is NULL\n");
        return;
    }
    
    printf("\n\033[1;34m================== [ Supplier Information ] ==================\033[0m\n");
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;215;0m%.8s\033[0m\n", "Supplier ID", node->data.SupplierId);
    printf(" \033[1m%-20s:\033[0m \033[38;2;0;255;255m%s\033[0m\n", "Supplier Name", node->data.SupplierName);
    printf(" \033[1m%-20s:\033[0m \033[38;2;144;238;144m%lu\033[0m\n", "Quantity", node->data.Quantity);
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;105;180m%lu\033[0m\n", "Contact", node->data.Contact);
    printf(" \033[1m%-20s:\033[0m \033[38;2;255;165;0m₹ %.2f\033[0m\n", "Turnover", node->data.Turnover);
    printf("\033[1;34m===============================================================\033[0m\n");
}
