#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <sys/select.h>
#include <errno.h>
#include "../../include/include.h"

#define MAX_LINE_LENGTH 256

// SUPP_ID,MED_ID,BATCH_ID,BATCH_QUANTITY,EXPIRATION_DATE(YYYYMMDD),PURCHASE_PRICE <- each line of file

int Get_Batches_From_File(void **MedRoot, void **SupRoot, void **ExpRoot, void **TurnOverRoot, void **UniqueMedRoot, const char *file_path)
{
    FILE *file = fopen(file_path, "r");
    if (!file) {
        fprintf(stderr, "\033[1m\033[38;2;255;0;0mERROR:\033[0m %s: \033[1;38;2;255;215;0m%s\033[0m\n", strerror(errno), file_path);
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file)) {
        char supplier_id[8] = {0};
        char med_id[8] = {0};
        char batch_number[8] = {0};
        uint64_t batch_quantity = 0;
        uint64_t expiration_date = 0;
        real purchase_price = 0.0;

        char *token = strtok(line, ",");
        if (!token) continue;
        strncpy(supplier_id, token, sizeof(supplier_id) - 1);

        uint64_t Skey = 0;
        uint64_t Mkey = 0;
        uint64_t Bkey = 0;
        char *writeHead = (char *)(&Skey);
        for (int i = 0; i < 8; ++i) {
            writeHead[i] = supplier_id[7 - i];
        }
        void *supp = Search(*SupRoot, Skey);

        if (supp) {
            SupplierNode *suppNode = supp;
            token = strtok(NULL, ",");
            if (!token) continue;
            strncpy(med_id, token, sizeof(med_id) - 1);

            writeHead = (char *) (&Mkey);
            for (int i = 0; i < 8; ++i) {
                writeHead[i] = med_id[7 - i];
            }

            void *med = Search(*MedRoot, Mkey);

            if (med) {
                MedicineNode *medNode = med;
                token = strtok(NULL, ",");
                if (!token) continue;
                strncpy(batch_number, token, sizeof(batch_number) - 1);

                writeHead = (char *) (&Bkey);
                for (int i = 0; i < 8; ++i) {
                    writeHead[i] = batch_number[7 - i];
                }

                void *already_exists = Search(medNode->BatchRoot, Bkey);
                if (!already_exists) {

                    token = strtok(NULL, ",");
                    if (!token) continue;
                    batch_quantity = strtoull(token, NULL, 10);

                    token = strtok(NULL, ",");
                    if (!token) continue;
                    expiration_date = strtoull(token, NULL, 10);

                    token = strtok(NULL, ",");
                    if (!token) continue;
                    purchase_price = (real)atof(token);

                    BatchNode *batch_node = (BatchNode *)calloc(1, sizeof(BatchNode));
                    if (!batch_node) {
                        perror("Memory allocation error");
                        fclose(file);
                        return 1;
                    }

                    // Fill BatchData
                    strncpy(batch_node->batch.BatchId, batch_number, sizeof(batch_node->batch.BatchId));
                    batch_node->batch.BatchQuantity = batch_quantity;
                    batch_node->batch.ExpiryDate = expiration_date;
                    batch_node->batch.PurchasePrice = purchase_price;
                    batch_node->AssociateSupp = (SupplierNode *)supp;
                    batch_node->AssociateMed = (MedicineNode *)med;
                    Insert(&(medNode->BatchRoot), Bkey, batch_node);

                    medNode->medicine.TotalQuantity += batch_quantity;
                    MedRef *SMB = Search(suppNode->MedRoot, Mkey); // supplier-medicine-batch bridge (medicine ref node)
                    if (!SMB) {
                        SMB = calloc(1, sizeof(MedRef));
                        SMB->medicine = med;
                        uint64_t oldMedCount = suppNode->MedCount;
                        uint64_t encryptedOldCount = INT64_MAX - oldMedCount;
                        void **umr = SearchAddress(*UniqueMedRoot, encryptedOldCount);
                        if (umr) {
                            void *exists = Search(*umr, Skey);
                            if (exists) Delete(umr, Skey);
                            if (*umr == NULL) Delete(UniqueMedRoot, encryptedOldCount);
                        }
                        uint64_t newMedCount = oldMedCount + 1;
                        uint64_t encryptedNewCount = INT64_MAX - newMedCount;
                        Insert(&(suppNode->MedRoot), Mkey, SMB);
                        suppNode->MedCount += 1;
                        umr = SearchAddress(*UniqueMedRoot, encryptedNewCount);
                        if (!umr) Insert(UniqueMedRoot, encryptedNewCount, NULL);
                        umr = SearchAddress(*UniqueMedRoot, encryptedNewCount);
                        Insert(umr, Skey, suppNode);
                    }
                    Insert(&(SMB->BatchRoot), Bkey, batch_node);

                    void **exp = SearchAddress(*ExpRoot, expiration_date);
                    if (!exp) {
                        Insert(ExpRoot, expiration_date, NULL);
                        exp = SearchAddress(*ExpRoot, expiration_date);
                    }
                    SMB = Search(*exp, Mkey);
                    if (!SMB) {
                        SMB = calloc(1, sizeof(MedRef));
                        SMB->medicine = med;
                        Insert(exp, Mkey, SMB);
                    }
                    Insert(&(SMB->BatchRoot), Bkey, batch_node);

                    real prevTurnOver = suppNode->data.Turnover;
                    real newTurnOver = prevTurnOver + purchase_price;
                    suppNode->data.Turnover = newTurnOver;
                    
                    REALTONATURAL oldBits, newBits;
                    memcpy(&oldBits, &prevTurnOver, sizeof(oldBits));
                    memcpy(&newBits, &newTurnOver, sizeof(newBits));

                    REALTONATURAL encryptedOldTurnOver = REAL_MAX - oldBits;
                    REALTONATURAL encryptedNewTurnOver = REAL_MAX - newBits;

                    void **TOR = SearchAddress(*TurnOverRoot, encryptedOldTurnOver);
                    if (TOR) {
                        if (Search(*TOR, Skey)) {
                            Delete(TOR, Skey);
                            if (*TOR == NULL) {
                                Delete(TurnOverRoot, encryptedOldTurnOver);
                            }
                        }
                    }

                    TOR = SearchAddress(*TurnOverRoot, encryptedNewTurnOver);
                    if (!TOR) {
                        Insert(TurnOverRoot, encryptedNewTurnOver, NULL);
                        TOR = SearchAddress(*TurnOverRoot, encryptedNewTurnOver);
                    }
                    Insert(TOR, Skey, suppNode);
                }
            }
        }
    }

    fclose(file);
    return 0;
}
