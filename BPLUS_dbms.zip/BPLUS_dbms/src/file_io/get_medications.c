#include "./../../include/include.h"
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE_LENGTH 256

// ID,NAME,REORDER_LVL,PRICE_PER_UNIT,TOTAL_SALES,QUANTITY(IGNORED)
int Get_Medicines_From_File(void **MedRoot, const char *file_path) {
    FILE *file = fopen(file_path, "r");
    if (!file) {
        fprintf(stderr, "\033[1m\033[38;2;255;0;0mERROR:\033[0m %s: \033[1;38;2;255;215;0m%s\033[0m\n", strerror(errno), file_path);
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file)) {
        char med_id[8] = {0};
        char med_name[48] = {0};
        uint64_t reorder_level = 0;
        float price_per_unit = 0.0f;
        uint64_t total_sales = 0;

        char *token = strtok(line, ",");
        if (!token) continue;
        strncpy(med_id, token, sizeof(med_id) - 1);

        token = strtok(NULL, ",");
        if (!token) continue;
        strncpy(med_name, token, sizeof(med_name) - 1);

        // Handle potential commas in the medicine name
        while ((token = strtok(NULL, ",")) && !isdigit(token[0])) {
            strncat(med_name, ",", sizeof(med_name) - strlen(med_name) - 1);
            strncat(med_name, token, sizeof(med_name) - strlen(med_name) - 1);
        }

        if (!token) continue;
        reorder_level = strtoull(token, NULL, 10);

        token = strtok(NULL, ",");
        if (!token) continue;
        price_per_unit = atof(token);

        token = strtok(NULL, ",");
        if (!token) continue;
        total_sales = strtoull(token, NULL, 10);

        // Ignore the final field: QUANTITY
        // token = strtok(NULL, ","); // optionally skip

        // Clear key, then copy exactly the 8 bytes from reversed buffer
        uint64_t key = 0;
        char *writeHead = (char *)(&key);
        for (int i = 0; i < 8; ++i) {
            writeHead[i] = med_id[7 - i];
        }
        void *exists = Search(*MedRoot, key);
        if (!exists) {
            MedicineNode *med_node = (MedicineNode *)calloc(1, sizeof(MedicineNode));
            if (!med_node) {
                perror("Memory allocation error");
                fclose(file);
                return 1;
            }

            strncpy(med_node->medicine.MedId, med_id, sizeof(med_node->medicine.MedId));
            strncpy(med_node->medicine.MedName, med_name, sizeof(med_node->medicine.MedName));
            med_node->medicine.ReorderLevel = reorder_level;
            med_node->medicine.price_per_unit = price_per_unit;
            med_node->medicine.TotalSales = total_sales;
            med_node->medicine.TotalQuantity = 0; // Ignored field

            Insert(MedRoot, key, med_node);
        }
    }

    fclose(file);
    return 0;
}
