#include "../../include/include.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#define MAX_LINE_LENGTH 256

// SUPP_ID,SUPP_NAME,SUPP_CONTACT,QUANTITY_SUPPLIED,TURNOVER <- file line schema

int Get_Suppliers_From_File(void **SuppRoot, const char *file_path) {
    FILE *file = fopen(file_path, "r");
    if (!file) {
        fprintf(stderr, "\033[1m\033[38;2;255;0;0mERROR:\033[0m %s\n", strerror(errno));
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    while (fgets(line, sizeof(line), file)) {
        char supp_id[8] = {0};
        char supp_name[48] = {0};
        uint64_t contact = 0;
        uint64_t quantity = 0;
        float turnover = 0.0f;

        char *token = strtok(line, ",");
        if (!token) continue;
        strncpy(supp_id, token, sizeof(supp_id) - 1);

        token = strtok(NULL, ",");
        if (!token) continue;
        strncpy(supp_name, token, sizeof(supp_name) - 1);

        while ((token = strtok(NULL, ",")) && !isdigit(token[0])) {
            strncat(supp_name, ",", sizeof(supp_name) - strlen(supp_name) - 1);
            strncat(supp_name, token, sizeof(supp_name) - strlen(supp_name) - 1);
        }

        if (!token) continue;
        contact = strtoull(token, NULL, 10);

        token = strtok(NULL, ",");
        if (!token) continue;
        quantity = strtoull(token, NULL, 10);

        token = strtok(NULL, ",");
        if (!token) continue;
        turnover = atof(token);

        uint64_t key = 0;
        char *writeHead = (char *) (&key);
        for (int i = 0; i < 8; ++i) {
            writeHead[i] = supp_id[7 - i];  
        }
        void *exists = Search(*SuppRoot, key);
        if (!exists) {
            SupplierNode *supp_node = (SupplierNode *)calloc(1, sizeof(SupplierNode));
            if (!supp_node) {
                perror("Memory allocation error");
                fclose(file);
                return 1;
            }

            strncpy(supp_node->data.SupplierId, supp_id, sizeof(supp_node->data.SupplierId));
            strncpy(supp_node->data.SupplierName, supp_name, sizeof(supp_node->data.SupplierName));
            supp_node->data.Contact = contact;
            supp_node->data.Quantity = quantity;
            supp_node->data.Turnover = turnover;

            Insert(SuppRoot, key, supp_node);
        }
    }

    fclose(file);
    return 0;
}
