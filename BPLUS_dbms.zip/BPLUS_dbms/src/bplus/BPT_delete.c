#include "../../include/include.h"
#include <stdint.h>

bool TransactionFromLeft(InternalNode *parent, int index)
{
    bool status = false;
    if (index >= 0) {
        if (*((NODE_KIND *)(parent->children[0])) == LEAF) {
            LeafNode *deficientChild = parent->children[index];
            LeafNode *donorChild = parent->children[index - 1];

            if (donorChild->numData > KEYS_LOWER_BOUND_LEAF_NODE) {
                parent->keys[index] = donorChild->keys[donorChild->numData - 1];
                uint64_t *keys = deficientChild->keys;
                void **data = deficientChild->data;
                for (int i = KEYS_LOWER_BOUND_LEAF_NODE; i > 0; --i) {
                    keys[i] = keys[i - 1];
                    data[i] = data[i - 1];
                }
                data[0] = donorChild->data[donorChild->numData - 1];
                keys[0] = donorChild->keys[donorChild->numData - 1];
                deficientChild->numData += 1;
                donorChild->numData -= 1;
                status = true;
            }
        } else {
            InternalNode *deficientChild = parent->children[index];
            InternalNode *donorChild = parent->children[index - 1];

            if (donorChild->numKeys > KEYS_LOWER_BOUND_INTERNAL_NODE) {
                uint64_t *keys = deficientChild->keys;
                void **children = deficientChild->children;
                for (int i = KEYS_LOWER_BOUND_INTERNAL_NODE; i > 0; --i) {
                    keys[i] = keys[i - 1];
                    children[i] = children[i - 1];
                }
                children[0] = deficientChild->firstChild;
                deficientChild->firstChild = donorChild->children[donorChild->numKeys - 1];
                deficientChild->keys[0] = parent->keys[index];
                parent->keys[index] = donorChild->keys[donorChild->numKeys - 1];
                deficientChild->numKeys += 1;
                donorChild->numKeys -= 1;
                status = true;
            }
        }
    }
    return status;
}

bool TransactionFromRight(InternalNode *parent, int index)
{
    bool status = false;
    if (index < parent->numKeys - 1) {
        if (*((NODE_KIND *)(parent->children[0])) == LEAF) {
            LeafNode *deficientChild = parent->children[index];
            LeafNode *donorChild = parent->children[index + 1];

            if (donorChild->numData > KEYS_LOWER_BOUND_LEAF_NODE) {
                deficientChild->data[deficientChild->numData] = donorChild->data[0];
                deficientChild->keys[deficientChild->numData] = donorChild->keys[0];

                uint64_t *keys = donorChild->keys;
                void **data = donorChild->data;
                int numData = donorChild->numData;
                for (int i = 0; i < numData - 1; ++i) {
                    keys[i] = keys[i + 1];
                    data[i] = data[i + 1];
                }

                parent->keys[index + 1] = donorChild->keys[0];
                deficientChild->numData += 1;
                donorChild->numData -= 1;
                status = true;
            }
        } else {
            InternalNode *deficientChild = parent->children[index];
            InternalNode *donorChild = parent->children[index + 1];

            if (donorChild->numKeys > KEYS_LOWER_BOUND_INTERNAL_NODE) {
                deficientChild->keys[deficientChild->numKeys] = parent->keys[index + 1];
                deficientChild->children[deficientChild->numKeys] = donorChild->firstChild;
                parent->keys[index + 1] = donorChild->keys[0];

                uint64_t *keys =  donorChild->keys;
                void **children = donorChild->children;
                donorChild->firstChild = children[0];

                for (int i = 0; i < donorChild->numKeys - 1; ++i) {
                    keys[i] = keys[i + 1];
                    children[i] = children[i + 1];
                }

                deficientChild->numKeys += 1;
                donorChild->numKeys -= 1;
                status = true;
            }
        }
    }
    return status;
}

bool Merge(InternalNode *parent, int index)
{
    bool status = false;
    if (index >= 0) {
        if ((*(NODE_KIND *)(parent->children[index])) == LEAF) {
            LeafNode *leftChild = parent->children[index - 1];
            LeafNode *deficientChild = parent->children[index];

            memcpy(leftChild->keys + leftChild->numData,
                   deficientChild->keys,
                   deficientChild->numData * sizeof(uint64_t));

            memcpy(leftChild->data + leftChild->numData,
                   deficientChild->data,
                   deficientChild->numData * sizeof(uint64_t));

            leftChild->next = deficientChild->next;
            if (deficientChild->next) {
                deficientChild->next->prev = leftChild;
            }
            leftChild->numData += deficientChild->numData;

            uint64_t *keys = parent->keys;
            void **children = parent->children;
            int numKeys = parent->numKeys - 1;
            
            for (int i = index; i < numKeys; ++i) {
                keys[i] = keys[i + 1];
                children[i] = children[i + 1];
            }
            parent->numKeys = numKeys;

            free(deficientChild);
        } else {
            InternalNode *leftChild = parent->children[index - 1];
            InternalNode *deficientChild = parent->children[index];

            uint64_t medKey = parent->keys[index];

            uint64_t *lkeys = leftChild->keys;
            uint64_t *dkeys = deficientChild->keys;
            uint64_t lNumkeys = leftChild->numKeys;
            uint64_t dNumkeys = deficientChild->numKeys;
            void **lchildren = leftChild->children;
            void **dchildren = deficientChild->children;
            
            lkeys[lNumkeys] = medKey;
            lchildren[lNumkeys] = dchildren[-1];
            lNumkeys++;

            memcpy(lkeys + lNumkeys, dkeys, dNumkeys * sizeof(uint64_t));
            memcpy(lchildren + lNumkeys, dchildren, dNumkeys * sizeof(void *));

            parent->numKeys -= 1;
            for (int i = index; i < parent->numKeys; ++i) {
                parent->keys[i] = parent->keys[i + 1];
                parent->children[i] = parent->children[i + 1];
            }

            leftChild->numKeys += deficientChild->numKeys + 1;
            free(deficientChild);
        }
    } else {
        if ((*(NODE_KIND *)(parent->children[index])) == LEAF) {
            LeafNode *rightChild = parent->children[index + 1];
            LeafNode *deficientChild = parent->children[index];

            memcpy(deficientChild->keys + deficientChild->numData,
                   rightChild->keys,
                   rightChild->numData * sizeof(uint64_t));

            memcpy(deficientChild->data + deficientChild->numData,
                   rightChild->data,
                   rightChild->numData * sizeof(uint64_t));

            deficientChild->next = rightChild->next;
            if (rightChild->next) {
                rightChild->next->prev = deficientChild;
            }
            deficientChild->numData += rightChild->numData;

            uint64_t *keys = parent->keys;
            void **children = parent->children;
            int numKeys = parent->numKeys - 1;

            for (int i = index + 1; i < numKeys; ++i) {
                keys[i] = keys[i + 1];
                children[i] = children[i + 1];
            }
            parent->numKeys = numKeys;

            free(rightChild);
        } else {
            InternalNode *rightChild = parent->children[index + 1];
            InternalNode *deficientChild = parent->children[index];

            uint64_t medKey = parent->keys[index + 1];

            uint64_t *rkeys = rightChild->keys;
            uint64_t *dkeys = deficientChild->keys;
            uint64_t rNumkeys = rightChild->numKeys;
            uint64_t dNumkeys = deficientChild->numKeys;
            void **rchildren = rightChild->children;
            void **dchildren = deficientChild->children;

            dkeys[dNumkeys] = medKey;
            dchildren[dNumkeys] = rchildren[-1];
            dNumkeys++;

            memcpy(dkeys + dNumkeys, rkeys, rNumkeys * sizeof(uint64_t));
            memcpy(dchildren + dNumkeys, rchildren, rNumkeys * sizeof(void *));

            parent->numKeys -= 1;
            for (int i = index + 1; i < parent->numKeys; ++i) {
                parent->keys[i] = parent->keys[i + 1];
                parent->children[i] = parent->children[i + 1];
            }

            deficientChild->numKeys += rightChild->numKeys + 1;
            free(rightChild);
        }
    }
    if (parent->numKeys < KEYS_LOWER_BOUND_INTERNAL_NODE) {
        status  = true;  
    }
    return status;
}

bool Deficiency(void *node, uint64_t key, uint64_t *successor)
{
    if (*((NODE_KIND *)(node)) == LEAF) {
        LeafNode *current = (LeafNode *)node;
        int index = search(current->keys, current->numData, key);
        uint64_t *keys = current->keys;
        void **data = current->data;
        int numData = current->numData - 1;

        for (int i = index; i < numData; ++i) {
            keys[i] = keys[i + 1];
            data[i] = data[i + 1];
        }
        current->numData = numData;

        if (index == 0) {
            *successor = keys[0];
        }

        if (numData < KEYS_LOWER_BOUND_LEAF_NODE) {
            return true;
        }
    } else {
        InternalNode *current = (InternalNode *)node;
        int index = search(current->keys, current->numKeys, key);
        bool isDeficiency = Deficiency(current->children[index], key, successor);

        if (index >= 0 && current->keys[index] == key) {
            current->keys[index] = *successor;
        }

        if (isDeficiency) {
            if (TransactionFromLeft(current, index)) {
                return false;
            } else if (TransactionFromRight(current, index)) {
                return false;
            } else {
                return Merge(current, index);
            }
        }
    }
    return false;
}

void Delete(void **root, uint64_t key)
{
    if (!*root) {
        return;
    }
    if ((*(NODE_KIND *)(*root)) == LEAF) {
        LeafNode *node = (LeafNode *)(*root);
        int index = search(node->keys, node->numData, key);
        void **data = node->data;
        uint64_t *keys = node->keys;
        int numData = node->numData - 1;
        if (numData == 0) {
            free(node);
            *root = NULL;
        }
        else {
            for (int i = index; i < numData; ++i) {
                keys[i] = keys[i + 1];
                data[i] = data[i + 1];
            }
            node->numData = numData;
        }
    }
    else {
        InternalNode *node = *root;
        uint64_t successor;
        Deficiency(node, key, &successor);
        if (node->numKeys == 0) {
            *root = node->firstChild;
            free(node);
        }
    }
}
