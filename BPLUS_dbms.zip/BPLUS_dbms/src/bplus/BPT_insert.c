#include "../../include/include.h"

void PushInInternal(InternalNode *node, int idx, uint64_t keyToInsert, void *rightChild) {
    uint64_t *keys = node->keys;
    void **children = node->children;

    for (int i = node->numKeys; i > idx; --i) {
        keys[i] = keys[i - 1];
        children[i] = children[i - 1];
    }

    node->numKeys += 1;
    keys[idx] = keyToInsert;
    children[idx] = rightChild;
}

void SplitInternal(InternalNode *node, int idx, uint64_t *key, void **rightChild) {
    InternalNode *newRight = CreateNode(INTERNAL);
    newRight->numKeys = KEYS_LOWER_BOUND_INTERNAL_NODE;

    memcpy(newRight->keys, &(node->keys[KEYS_LOWER_BOUND_INTERNAL_NODE + 1]),
           KEYS_LOWER_BOUND_INTERNAL_NODE * sizeof(uint64_t));
    memcpy(&(newRight->firstChild), &(node->children[KEYS_LOWER_BOUND_INTERNAL_NODE]),
           CHILDREN_LOWER_BOUND_INTERNAL_NODE * sizeof(void *));

    node->numKeys = KEYS_LOWER_BOUND_INTERNAL_NODE;
    uint64_t keyToPush = node->keys[KEYS_LOWER_BOUND_INTERNAL_NODE];
    uint64_t keyToInsert = *key;
    void *childToInsert = *rightChild;

    if (idx < KEYS_LOWER_BOUND_INTERNAL_NODE) {
        PushInInternal(node, idx, keyToInsert, childToInsert);
    } else if (idx == KEYS_LOWER_BOUND_INTERNAL_NODE) {
        PushInInternal(newRight, 0, keyToInsert, childToInsert);
    } else {
        PushInInternal(newRight, idx - KEYS_LOWER_BOUND_INTERNAL_NODE - 1, keyToInsert, childToInsert);
    }
    *key = keyToPush;
    *rightChild = newRight;
}

void PushInLeaf(LeafNode *node, int idx, uint64_t keyToInsert, void *rightChild) {
    uint64_t *keys = node->keys;
    void **data = node->data;

    for (int i = node->numData; i > idx; --i) {
        keys[i] = keys[i - 1];
        data[i] = data[i - 1];
    }

    node->numData += 1;
    keys[idx] = keyToInsert;
    data[idx] = rightChild;
}

void SplitLeaf(LeafNode *node, int idx, uint64_t *key, void **rightChild) {
    LeafNode *newRight = CreateNode(LEAF);
    newRight->numData = KEYS_LOWER_BOUND_LEAF_NODE;

    memcpy(newRight->keys, &(node->keys[KEYS_LOWER_BOUND_LEAF_NODE]),
           KEYS_LOWER_BOUND_LEAF_NODE * sizeof(uint64_t));
    memcpy(&(newRight->data), &(node->data[KEYS_LOWER_BOUND_LEAF_NODE]),
           KEYS_LOWER_BOUND_LEAF_NODE * sizeof(void *));

    node->numData = KEYS_LOWER_BOUND_LEAF_NODE;
    uint64_t keyToInsert = *key;
    void *childToInsert = *rightChild;

    if (idx < KEYS_LOWER_BOUND_LEAF_NODE) {
        PushInLeaf(node, idx, keyToInsert, childToInsert);
    } else {
        PushInLeaf(newRight, idx - KEYS_LOWER_BOUND_LEAF_NODE, keyToInsert, childToInsert);
    }
    *key = newRight->keys[0];
    *rightChild = newRight;

    newRight->next = node->next;
    if (newRight->next) {
        newRight->next->prev = newRight;
    }
    node->next = newRight;
    newRight->prev = node;

    // -------------------- TESTING -------------------------------------------------//
    /*
    for (int i = 0; i < node->numData; ++i) {
        printf("%lu ", node->keys[i]);
    }
    printf("\n");

    for (int i = 0; i < newRight->numData; ++i) {
        printf("%lu ", newRight->keys[i]);
    }
    printf("\n");
    */
}

bool PushDown(void *node, uint64_t key, void *value, uint64_t *keyPushUp, void **rightPushUp) {
    NODE_KIND kind = *(NODE_KIND *)node;
    int pos;

    if (kind == INTERNAL) {
        InternalNode *current = node;
        pos = search(current->keys, current->numKeys, key);
        if (PushDown(current->children[pos], key, value, keyPushUp, rightPushUp)) {
            if (current->numKeys < KEYS_UPPER_BOUND_INTERNAL_NODE) {
                PushInInternal(current, pos + 1, *keyPushUp, *rightPushUp);
                return false;
            } else {
                SplitInternal(current, pos + 1, keyPushUp, rightPushUp);
                return true;
            }
        }
    } else {
        LeafNode *current = node;
        pos = search(current->keys, current->numData, key);
        if (current->numData < KEYS_UPPER_BOUND_LEAF_NODE) {
            PushInLeaf(current, pos + 1, key, value);
            return false;
        } else {
            SplitLeaf(current, pos + 1, keyPushUp, rightPushUp);
            return true;
        }
    }
    return false;
}

void Insert(void **root, uint64_t key, void *value) {
    if (*root == NULL) {
        LeafNode *newRoot = CreateNode(LEAF);
        PushInLeaf(newRoot, 0, key, value);
        *root = newRoot;
    }
    else {
        uint64_t keyToInsert = key;
        void *rightChild = value;
        if (PushDown(*root, key, value, &keyToInsert, &rightChild)) {
            InternalNode *newroot = CreateNode(INTERNAL);
            newroot->numKeys = 1;
            newroot->keys[0] = keyToInsert;
            newroot->firstChild = *root;
            newroot->children[0] = rightChild;
            *root = newroot;
        }
    }
}
