#include "../../include/include.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SIZE 1000

char *Expand_Home_Path(const char *path) {
    if (path[0] == '~') {
        const char *home = getenv("HOME");
        if (!home) return NULL;

        char *expanded = malloc(strlen(home) + strlen(path));
        if (!expanded) return NULL;

        sprintf(expanded, "%s%s", home, path + 1); // skip the '~'
        return expanded;
    }
    return strdup(path);  // no ~, return as-is
}

int compare(const void *a, const void *b)
{
    if (a > b) {
        return 1;
    } else if (a == b) {
        return 0;
    }
    return -1;
}


void print_internal_keys_string(void *node)
{
    InternalNode *this = (InternalNode *)node;
    for (int i = 0; i < this->numKeys; ++i) {
        printf("%.8s : %016lx\n", (char *)&(this->keys[i]), this->keys[i]);
    }
}

int main()
{
    void *MedRoot = NULL;
    void *SupRoot = NULL;
    void *ExpRoot = NULL;

    void *TurnOverRoot  = NULL;
    void *UniqueMedRoot = NULL;

    char *mpath = Expand_Home_Path("~/Projects/pharmacy_mgmt/BPLUS_dbms/data/medication_data.txt");
    char *spath = Expand_Home_Path("~/Projects/pharmacy_mgmt/BPLUS_dbms/data/supplier_data.txt");
    char *bpath = Expand_Home_Path("~/Projects/pharmacy_mgmt/BPLUS_dbms/data/batch_data.txt");

    Get_Medicines_From_File(&MedRoot, mpath);
    Get_Suppliers_From_File(&SupRoot, spath);
    Get_Batches_From_File(&MedRoot, &SupRoot, &ExpRoot, &TurnOverRoot, &UniqueMedRoot, bpath);
    // BPT_travel(MedRoot);
    // print_internal_keys_string(MedRoot);
    // print_internal_keys_string(((InternalNode*)MedRoot)->firstChild);
    // uint64_t key = 0;
    // char med_id[8] = {0};
    // char *writeHead = (char *) (&key);
    // printf("Enter Id\n");
    // scanf("%s", med_id);
    // for (int i = 0; i < 8; ++i) {
    //     writeHead[i] = med_id[7 - i];
    // }
    // void *med = Search(MedRoot, key);
    // Print_Medicine_Info(med);
    // Delete(&MedRoot, key);
    

    /*  PRINTS BATCHES OF EACH MEDICATION

    LeafNode *llb = GetLL(MedRoot);
    LeafNode *ll = llb;
    while (ll) {
        for (int i = 0; i < ll->numData; ++i) {
            MedicineNode *node = (MedicineNode *)(ll->data[i]);
            printf("\t\033[1m%-20s:\033[0m \033[38;2;0;255;255m%s\033[0m\n", node->medicine.MedName, node->medicine.MedId);
            LeafNode *BLL = GetLL(node->BatchRoot);
            Print_BatchTable_Header();
            while (BLL) {
                for (int i = 0; i < BLL->numData; ++i) {
                    Print_BatchTable_Row(BLL->data[i]);
                }
                BLL = BLL->next;
            }
            Print_BatchTable_Footer();
        }
        ll = ll->next;
    }

    */


    /*  PRINTS BATCHES OF EACH SUPPLIER
    
    LeafNode *llb = GetLL(SupRoot);
    LeafNode *ll = llb;
    while (ll) {
        for (int i = 0; i < ll->numData; ++i) {
            SupplierNode *node = (SupplierNode *)(ll->data[i]);
            LeafNode *MLL = GetLL(node->MedRoot);
            Print_BatchTable_Header();
            while (MLL) {
                for (int j = 0; j < MLL->numData; ++j) {
                    LeafNode *BLL = GetLL(((MedRef *)(MLL->data[j]))->BatchRoot);
                    while (BLL) {
                        for (int k = 0; k < BLL->numData; ++k) {
                            Print_BatchTable_Row(BLL->data[k]);
                        }
                        BLL = BLL->next;
                    }
                }
                MLL = MLL->next;
            }
            Print_BatchTable_Footer();
        }
        ll = ll->next;
    }

    */

    /*  PRINTS BATCHES OF EACH DATE
    
    LeafNode *llb = GetLL(ExpRoot);
    LeafNode *ll = llb;
    Print_BatchTable_Header();
    while (ll) {
        for (int i = 0; i < ll->numData; ++i) {
            LeafNode *MRDLL = GetLL(ll->data[i]);
            while (MRDLL) {
                for (int j = 0; j < MRDLL->numData; ++j) {
                    LeafNode *BLL = GetLL(((MedRef *)(MRDLL->data[j]))->BatchRoot);
                    while (BLL) {
                        for (int k = 0; k < BLL->numData; ++k) {
                            Print_BatchTable_Row(BLL->data[k]);
                        }
                        BLL = BLL->next;
                    }
                }
                MRDLL = MRDLL->next;
            }
        }
        ll = ll->next;
    }
    Print_BatchTable_Footer();

    */

    /*  PRINTS BATCHES OF EACH SUPPLIER
    
    LeafNode *llb = GetLL(TurnOverRoot);
    LeafNode *ll = llb;
    while (ll) {
        for (int i = 0; i < ll->numData; ++i) {
            LeafNode *stree = GetLL(ll->data[i]);
            // Print_BatchTable_Header();
            while (stree) {
                for (int j = 0; j < stree->numData; ++j) {
                    SupplierNode *node = stree->data[j];
                    printf("%-10s %f\n", node->data.SupplierId, node->data.Turnover);
                }
                stree = stree->next;
            }
            // Print_BatchTable_Footer();
        }
        ll = ll->next;
    }

    */

    // /*  PRINTS BATCHES OF EACH SUPPLIER
    
    LeafNode *llb = GetLL(UniqueMedRoot);
    LeafNode *ll = llb;
    while (ll) {
        for (int i = 0; i < ll->numData; ++i) {
            LeafNode *stree = GetLL(ll->data[i]);
            // Print_BatchTable_Header();
            while (stree) {
                for (int j = 0; j < stree->numData; ++j) {
                    SupplierNode *node = stree->data[j];
                    printf("%-10s %lu\n", node->data.SupplierId, node->MedCount);
                }
                stree = stree->next;
            }
            // Print_BatchTable_Footer();
        }
        ll = ll->next;
    }

    // */

    // while (ll) {
    //     for (int i = 0; i < ll->numData; ++i) {
    //         Print_Supplier_Info(ll->data[i]);
    //     }
    //     ll = ll->next;
    // }
    return 0;
}

