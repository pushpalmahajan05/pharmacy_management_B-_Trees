#include "BPT.h"
#include <stdint.h>
#include <stdio.h>
#include <sys/types.h>
#include <time.h>

void *CreateNode(NODE_KIND kind)
{
    void* new = calloc(1, (kind) ? sizeof(InternalNode): sizeof(LeafNode));
    *(NODE_KIND *)new = kind;
    return new;
}

int search(uint64_t *arr, int size, uint64_t target)
{
    int left = 0;
    int right = size - 1;
    int mid;
    int candidate = -1;
    while (left <= right) {
        mid = (left + right) >> 1;
        if (arr[mid] <= target) {
            candidate = mid;
            left = mid + 1;
        }
        else {
            right = mid - 1;
        }
    }
    return candidate;
}

//Common Search Function.
void* Search_node(void* root, uint64_t key) {
    if (root == NULL) return NULL;

    void* current = root;
    
    while (*(NODE_KIND *)current == INTERNAL) {
        InternalNode* internalNode = (InternalNode*)current;
        int index = search(internalNode->keys, internalNode->numKeys, key);
        current = internalNode->children[index];
    }

    LeafNode* leaf = (LeafNode*)current;
    int index = search(leaf->keys, leaf->numData, key);

    if (index != -1 && leaf->keys[index] == key) {
        return leaf->data[index]; 
    }
    
    return NULL; 
}

//Travel Function(can be used for range search)
void BPT_travel(void *node)
{
    if (node) {
        NODE_KIND kind = *(NODE_KIND *)node;
        if (kind == INTERNAL) {
            InternalNode *current = (InternalNode *)node;

            for (int i = 0; i < current->numKeys; ++i) {
                printf("%ld ", current->keys[i]);
            }
            printf("\n");

            BPT_travel(current->firstChild);
            for (int i = 0; i < current->numKeys; ++i) {
                BPT_travel(current->children[i]);
            }
        } else {
            LeafNode *current = (LeafNode *)node;

            for (int i = 0; i < current->numData; ++i) {
                printf("%ld ", current->keys[i]);
            }
            printf("\n");
        }
    }
}

void **SearchAddress(void **root, uint64_t key) {
    if (root == NULL) return NULL;

    void* current = *root;
    if (current) {
    
    while (*(NODE_KIND *)current == INTERNAL) {
        InternalNode* internalNode = (InternalNode*)current;
        int index = search(internalNode->keys, internalNode->numKeys, key);
        current = internalNode->children[index];
    }

    LeafNode* leaf = (LeafNode*)current;
    int index = search(leaf->keys, leaf->numData, key);

    if (index != -1 && leaf->keys[index] == key) {
        return &(leaf->data[index]); 
    }
    }
    return NULL; 
}
void *Search_By_MedID(void *root, uint64_t key);
void *Search_By_SuppID(void *root, uint64_t key);
void *Search_By_Batch(void *root, uint64_t key1, uint64_t key2);
void Stock_Alert(void *root, uint64_t key) {
    
}


//Converting from date to days
int days_since_2000(int yyyymmdd) {
    struct tm date = {0}, base = {0};

    int year = yyyymmdd / 10000;
    int month = (yyyymmdd / 100) % 100;
    int day = yyyymmdd % 100;

    date.tm_year = year - 1900;
    date.tm_mon = month - 1;
    date.tm_mday = day;

    base.tm_year = 2000 - 1900;
    base.tm_mon = 0;
    base.tm_mday = 1;

    time_t t_date = mktime(&date);
    time_t t_base = mktime(&base);

    if (t_date == -1 || t_base == -1) return -1; // error

    return (int)((t_date - t_base) / (60 * 60 * 24));
}

//Converting from days to date
int date_from_days(int days) {
    struct tm base = {0};

    base.tm_year = 2000 - 1900;
    base.tm_mon = 0;
    base.tm_mday = 1;

    time_t t = mktime(&base);
    t += (time_t)days * 24 * 60 * 60;

    struct tm *result = localtime(&t);
    if (!result) return -1; // error

    return (result->tm_year + 1900) * 10000 + (result->tm_mon + 1) * 100 + result->tm_mday;
}

void AddSupplier(void **SuppRoot)
